<?php require_once('includes/session.php');
       require_once('includes/conn.php');
       require_once('check.php');    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>Traffic Fine Management System- DASHBOARD</title>

         <!-- Bootstrap CSS CDN -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- Our Custom CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/awesome/font-awesome.css">
        <link rel="stylesheet" href="assets/css/animate.css">
    </head>
    <body>



        <div class="wrapper">
            <!-- Sidebar Holder -->
            <nav id="sidebar" class="sammacmedia">
                <div class="sidebar-header">
                    <h3>Traffic Fine Management System</h3>
                    <strong>TFMSystem</strong>
                </div>

                <ul class="list-unstyled components">
                    <li class="active">
                        <a href="dashboard.php">
                            <i class="fa fa-th"></i>
                           Dashboard
                        </a>
                    </li>

                  
                 <?php
                   
                   // Admin Access Level
                   
                    if($_SESSION['permission']==1){

                    ?>
                    <li>
                        <a href="a_users.php">
                            <i class="fa fa-user"></i>
                            Add Officers
                        </a>
                    </li>
                    
                     <li>
                        <a href="ViolationCat.php">
                            <i class="fa fa-plus"></i>
                             Add Traffic Violation Types
                        </a>
                    </li>


                    <li>
                        <a href="v_users.php">
                            <i class="fa fa-table"></i>
                            View Officers
                        </a>
                    </li>



                     <li>
                        <a href="paymentview.php">
                            <i class="fa fa-table"></i>
                             View Payment Records
                        </a>
                    </li>

                     <li>
                        <a href="show_payment.php">
                            <i class="fa fa-table"></i>
                             Statistical Data
                        </a>
                    </li>




                    <?php }

                    ?>


                   <?php
                   
                   // OIC Access Level
                   
                    if($_SESSION['permission']==2){

                    ?>
  
                    <li>
                        <a href="v_users.php">
                            <i class="fa fa-table"></i>
                            View Officers
                        </a>
                    </li>






                    <?php }

                    ?>


                   <?php
                   
                   // PO Access Level
                   
                    if($_SESSION['permission']==3){

                    ?>
  


                    <?php }

                    ?>

                    <li>
                        <a href="v_ViolationCat.php">
                            <i class="fa fa-table"></i>
                             View Violation Categories
                        </a>
                    </li>

                    <li>
                        <a href="tickets.php">
                            <i class="fa fa-plus"></i>
                             Issue Fine Ticket
                        </a>
                    </li>

                    <li>
                        <a href="payment.php">
                            <i class="fa fa-plus"></i>
                             Issue Fine Payment
                        </a>
                    </li>



                    
                    <li>
                        <a href="settings.php">
                            <i class="fa fa-cog"></i>
                            Settings
                        </a>
                    </li>
                </ul>
            </nav>


            <!-- Page Content Holder -->
            <div id="content">
             
                <div clas="col-md-12">
                    <img src="assets/image/ssm.jpg" class="img-thumbnail">
                    </div>
         
                
                <nav class="navbar navbar-default sammacmedia">
                    <div class="container-fluid">

                        <div class="navbar-header" id="sams">
                            <button type="button" id="sidebarCollapse" id="makota" class="btn btn-sam animated tada navbar-btn">
                                <i class="glyphicon glyphicon-align-left"></i>
                                <span>Menu</span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav navbar-right  makotasamuel">
                                <li><a href="#"><?php require_once('includes/name.php');?></a></li>
                                <li ><a href="logout.php"><i class="fa fa-power-off"> Logout</i></a></li>
           
                            </ul>
                        </div>
                    </div>
                </nav>

                <div class="line"></div>
                <div class="row">

                
                <?php

                
                if($_SESSION['permission']==1){

                ?>

                <div class="col-lg-6 col-md-6 ">
                    <div class="panel panel sammac sammacmedia">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-user fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $users;?></div>
                                    <div>Total Number Of Users</div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="panel panel strover sammacmedia">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-link fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $cases;?></div>
                                    <div>Total Number Of Cases</div>
                                </div>
                            </div>
                        </div>
                     
                    </div>
                </div>
           
           <?php }?>
                    
                    
            </div>
                <div class="line"></div>
                <footer>
            <p class="text-center">
            Traffic Fine Management System &copy;<?php echo date("Y ");?>Copyright. All Rights Reserved .</br>
            Powered By Department of Computer Engineering , Faculty of Engineering</br>
            University of Sri Jayewardenepura   
            </p>
            </footer>
            </div>
            
        </div>





        <!-- jQuery CDN -->
         <script src="assets/js/jquery-1.10.2.js"></script>
         <!-- Bootstrap Js CDN -->
         <script src="assets/js/bootstrap.min.js"></script>

         <script type="text/javascript">
             $(document).ready(function () {
                 $('#sidebarCollapse').on('click', function () {
                     $('#sidebar').toggleClass('active');
                 });
             });
             $('sams').on('click', function(){
                 $('makota').addClass('animated tada');
             });
         </script>
    </body>
</html>
