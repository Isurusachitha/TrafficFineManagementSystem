-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 09, 2019 at 12:11 PM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trafic`
--

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
CREATE TABLE IF NOT EXISTS `tickets` (
  `TicketNo` int(11) NOT NULL,
  `OfficerID` int(11) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `Surname` varchar(50) NOT NULL,
  `City` varchar(100) NOT NULL,
  `LicenseNo` int(11) NOT NULL,
  `Date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`TicketNo`, `OfficerID`, `FirstName`, `Surname`, `City`, `LicenseNo`, `Date`) VALUES
(12, 2020, 'Nirmal', 'Rajapaksha', 'Kalutara', 9595, '2011-10-20');

-- --------------------------------------------------------

--
-- Table structure for table `trafficfinepayment`
--

DROP TABLE IF EXISTS `trafficfinepayment`;
CREATE TABLE IF NOT EXISTS `trafficfinepayment` (
  `idTrafficFInePayment` int(11) NOT NULL AUTO_INCREMENT,
  `idTrafficViolation` int(11) NOT NULL,
  `FinePayment` float NOT NULL,
  `TimeStamp` varchar(45) NOT NULL,
  `payeementeeNIC` varchar(45) NOT NULL,
  `PaymenteeFName` varchar(45) NOT NULL,
  `PaymenteeLName` varchar(45) NOT NULL,
  `payementeeAddress` varchar(100) NOT NULL,
  PRIMARY KEY (`idTrafficFInePayment`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trafficviolation`
--

DROP TABLE IF EXISTS `trafficviolation`;
CREATE TABLE IF NOT EXISTS `trafficviolation` (
  `idTrafficViolation` int(11) NOT NULL AUTO_INCREMENT,
  `ViolationTypeID` varchar(45) NOT NULL,
  `IssueOffierID` int(20) NOT NULL,
  `TypeOfCrime` varchar(45) NOT NULL,
  `DriverLicenceNo` varchar(45) NOT NULL,
  `VehicalNo` varchar(45) NOT NULL,
  `DriverFname` varchar(45) NOT NULL,
  `DriverLname` varchar(45) NOT NULL,
  `DriverAddress` varchar(45) NOT NULL,
  `TimeStamp` varchar(45) NOT NULL,
  `ViolationLocation` varchar(100) NOT NULL,
  PRIMARY KEY (`idTrafficViolation`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trafficviolationcatagory`
--

DROP TABLE IF EXISTS `trafficviolationcatagory`;
CREATE TABLE IF NOT EXISTS `trafficviolationcatagory` (
  `ViolationTypeID` int(11) NOT NULL,
  `TrafficViolationName` varchar(45) NOT NULL,
  `DiscriptionofCrime` varchar(255) NOT NULL,
  `Fine` float NOT NULL,
  PRIMARY KEY (`ViolationTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trafficviolationcatagory`
--

INSERT INTO `trafficviolationcatagory` (`ViolationTypeID`, `TrafficViolationName`, `DiscriptionofCrime`, `Fine`) VALUES
(158, 'helmet', 'helmet', 1000),
(159, 'bike', 'bike', 100);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `joined` varchar(30) NOT NULL,
  `type` varchar(10) NOT NULL,
  `permission` varchar(10) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `OfficerID` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `email`, `username`, `password`, `joined`, `type`, `permission`, `gender`, `phone`, `OfficerID`) VALUES
(8, 'Isuru', 'Herath', 'my@sjp.ac.lk', 'isuru', '202cb962ac59075b964b07152d234b70', ' 30 Jun 2019 ', 'user', '1', 'M', '263789456123', 143245),
(9, 'Kasiz', 'Kavin', 'kasiz@gmail.com', 'kavezz', '202cb962ac59075b964b07152d234b70', ' 30 Jun 2019 ', 'user', '3', 'F', '263712894567', 1232144),
(10, 'sasda', 'asdfsa', 'asdd@gmail.com', 'sddd', '202cb962ac59075b964b07152d234b70', ' 30 Jun 2019 ', 'user', '1', 'F', '263777456888', 45655),
(11, 'asaanm', 'adased', 'asddd@gmail.com', 'asamn', '202cb962ac59075b964b07152d234b70', ' 30 Jun 2019 ', 'user', '1', 'F', '263789555111', 34345);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
